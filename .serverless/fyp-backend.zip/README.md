# FYP_Backend
 Code for the backend server of check-in beacon. 


Main Repo: 
https://github.com/Smudger1/FYP_Check-In_Beacon
