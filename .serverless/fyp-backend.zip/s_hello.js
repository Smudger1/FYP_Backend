
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'smudger',
  applicationName: 'final-year-project',
  appUid: 'VD6hHWYdMQCcWbzVvc',
  orgUid: '9b7bac41-fdcc-4f9b-93e5-391c54683d48',
  deploymentUid: 'b8f84c2b-d363-47c5-a8a3-a6c6770d91a1',
  serviceName: 'fyp-backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'fyp-backend-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}